export class CreateNoticeDto {}

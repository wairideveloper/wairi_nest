export class Notice {}

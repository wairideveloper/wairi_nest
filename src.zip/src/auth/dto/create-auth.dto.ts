export class CreateAuthDto {
  id: string;
  email: string;
  name: Buffer;
  phone: Buffer;
  passwd: string;
  level: number;
}

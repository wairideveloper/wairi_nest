export class CreateCampaignDto {}

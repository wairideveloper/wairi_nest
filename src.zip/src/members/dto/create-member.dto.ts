export class CreateMemberDto {}

export interface PaginationOptions {

    take: number;
    // pageSize: number;
    page: number;
}